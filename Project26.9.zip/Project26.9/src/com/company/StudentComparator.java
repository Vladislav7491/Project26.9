package comparator;

import model.Student;

import java.util.Comparator;

public interface StudentComparator extends Comparator<Student> {
}
