package comparator;

import model.University;

import java.util.Comparator;

public interface UniversityComparator extends Comparator<University> {
}