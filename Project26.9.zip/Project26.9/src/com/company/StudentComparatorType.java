package enums;

public enum StudentComparatorType {

    UNIVERSITY_ID,
    FULL_NAME,
    COURSE,
    AVG_EXAM_SCORE
}